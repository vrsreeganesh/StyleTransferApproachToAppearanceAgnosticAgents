#!/bin/bash

# Define the parameters to vary
use_act_values=(1)
img_aug_values=(0)
less_cmd_values=(0)
steer_aug_values=(0)
rand_steer_keywords=("NoRAND")

# Loop through each combination of parameters
for use_act in "${use_act_values[@]}"; do
    for img_aug in "${img_aug_values[@]}"; do
        for less_cmd in "${less_cmd_values[@]}"; do
            for steer_aug in "${steer_aug_values[@]}"; do
                for rand_steer_keyword in "${rand_steer_keywords[@]}"; do
                    # Construct the unique ID based on parameter values
                    id="use_act_${use_act}_img_aug_${img_aug}_less_cmd_${less_cmd}_steer_aug_${steer_aug}_rand_steer_keyword_${rand_steer_keyword}"

                    # Run the Python script with the current parameter combination
                    python train_baseline.py \
                        --logdir ./models \
                        --root_dir /projectnb/mlrobot/animikh/datasets/sim2realrep1/sim2real-old-data \
                        --parallel_training 0 \
                        --batch_size 32 \
                        --workers 16 \
                        --backbone regnety_002 \
                        --id "$id" \
                        --use_act "$use_act" \
                        --img_aug "$img_aug" \
                        --steer_aug "$steer_aug" \
                        --dropout 0 \
                        --epochs 30 \
                        --rand_steer_keywords "$rand_steer_keyword" \
                        --less_cmd "$less_cmd" \
                        --val_percent 0.2 \
                        --data_config maskcontd
                done
            done
        done
    done
done
