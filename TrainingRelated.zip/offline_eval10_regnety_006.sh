#!/bin/bash -l

# specifying arguments to the batch job. Its easier to enter it here
#$ -P rlvn
#$ -l h_rt=24:00:00
#$ -pe omp 8
#$ -N E10_Y6
#$ -m e
#$ -l gpus=1
#$ -l gpu_type=V100

# module loading
ml miniconda
conda activate /projectnb/rlvn/students/vrs/anaconda3/envs/tfuse

python evaluate_offline10_regnety_006.py --model_root_dir ./models10_regnety_006 --eval_data /projectnb/rlvn/students/vrs/DLProject/outdoor/FastSAM_Eval && python evaluate_offline10_regnety_006.py --model_root_dir ./models10_regnety_006 --eval_data /projectnb/rlvn/students/vrs/DLProject/indoor/FastSAM_Eval