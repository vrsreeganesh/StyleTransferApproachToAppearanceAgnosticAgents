import subprocess
import os

# Define the parameters to vary

dropouts = [0.0]
backbones = ["regnety_008", "regnety_016"]
data_configs = [
    'rgb',
    'rgbd',
    'mask',
    'maskd',
    'contd',
    'maskcontd',
]


i = 0
total_jobs = 5
num_gpus = 1
num_cpus = 8
max_epochs = 35
train_dir = "/projectnb/mlrobot/animikh/datasets/sim2realrep1/sim2real-old-data"
log_dir = "./models/"
projects = ["ml4adr", "mlrobot", "rlvn"]

for data_config in data_configs:
    for backbone in backbones:
        job_id = f"{backbone}"
        # Construct the unique ID based on parameter values
        id = f"s2rp1_{data_config}_{job_id}"

        project = projects[i % len(projects)]

        # Check if the model already exists, if it does, don't schedule
        check_dir = os.path.join(log_dir, f"{id}_{backbone}")
        model_path = os.path.join(check_dir, f'model_{max_epochs}.pth')
        if os.path.exists(model_path):
            # print(f"[SKIPPING] Model Exists.. Skipping: {model_path}")
            continue



        # Define the base script
        script_template = f"""#!/bin/bash -l
#$ -P {project}
#$ -N {id}
#$ -pe omp {num_cpus}
#$ -l gpus={num_gpus}
#$ -l gpu_c=7.0
#$ -m as
#$ -o {job_id}_{i}.out
#$ -e {job_id}_{i}.err
#$ -l h_rt=12:00:00
#$ -j y

module load gcc
module load libjpeg-turbo
module load opengl_glew/1.13.0
module load opencv/4.5.5
module load openmpi/3.1.4
module load xerces-c/3.2.2
ml miniconda && ml pytorch/1.11.0 && conda activate rlvn

dt=$(date '+%d/%m/%Y %H:%M:%S');
echo "Job started: $dt"
"""

        script_content = [
            script_template,
            "python train_baseline.py ",
            f"--logdir {log_dir} ",
            f"--root_dir {train_dir} ",
            f"--parallel_training 0 ",
            f"--batch_size 8 ",
            f"--workers 8 ",
            f"--backbone {backbone} ",
            f"--id {id} ",
            f"--use_act 1 ",
            f"--img_aug 0 ",
            f"--steer_aug 0 ",
            f"--dropout 0 ",
            f"--epochs {max_epochs} ",
            f"--prev_speed 0 "
            f"--less_cmd 0 "
            f"--val_percent 0.2 "
            f"--data_config {data_config}"
        ]

        script_content = "".join(script_content)

        # print(f"Scheduling: {id}")
        # i += 1
        # continue

        # Create a temporary script file
        with open(f"{id}.sh", "w") as temp_script:
            temp_script.write(script_content)

        # Submit the job using qsub
        subprocess.run(["qsub", f"{id}.sh"])
        print(f"Submitted job with ID: {id}")

        # Delete the temporary script file
        subprocess.run(["rm", f"{id}.sh"])

        i += 1 

