#!/bin/bash -l

# specifying arguments to the batch job. Its easier to enter it here
#$ -P rlvn
#$ -l h_rt=24:00:00
#$ -pe omp 8
#$ -N T07_R6
#$ -m e
#$ -l gpus=1
#$ -l gpu_type=V100

# module loading
ml miniconda
conda activate /projectnb/rlvn/students/vrs/anaconda3/envs/tfuse


# Define the parameters to vary
use_act_values=(1)
img_aug_values=(0)
less_cmd_values=(0)
steer_aug_values=(0)
rand_steer_keywords=("NoRAND")

# Loop through each combination of parameters
for use_act in "${use_act_values[@]}"; do
    for img_aug in "${img_aug_values[@]}"; do
        for less_cmd in "${less_cmd_values[@]}"; do
            for steer_aug in "${steer_aug_values[@]}"; do
                for rand_steer_keyword in "${rand_steer_keywords[@]}"; do
                    # Construct the unique ID based on parameter values
                    id="use_act_${use_act}_img_aug_${img_aug}_less_cmd_${less_cmd}_steer_aug_${steer_aug}_rand_steer_keyword_${rand_steer_keyword}"

                    # Run the Python script with the current parameter combination
                    python /projectnb/rlvn/students/vrs/DLProject/Custom_Arch/agent/train_baseline07_regnety_006.py \
                        --logdir ./models07_regnety_006 \
                        --root_dir /projectnb/rlvn/students/vrs/DLProject/sim2real-old-data \
                        --parallel_training 0 \
                        --batch_size 8 \
                        --workers 16 \
                        --backbone regnety_006 \
                        --id "$id" \
                        --use_act "$use_act" \
                        --img_aug "$img_aug" \
                        --steer_aug "$steer_aug" \
                        --dropout 0 \
                        --epochs 30 \
                        --rand_steer_keywords "$rand_steer_keyword" \
                        --less_cmd "$less_cmd" \
                        --val_percent 0.2 \
                        --data_config "rgb_NST_styleweightarg=1e4"
                done
            done
        done
    done
done
