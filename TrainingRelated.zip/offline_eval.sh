python evaluate_offline.py --model_root_dir ./models --eval_data /projectnb/mlrobot/animikh/datasets/real-world/outdoor/Eval && python evaluate_offline.py --model_root_dir ./models --eval_data /projectnb/mlrobot/animikh/datasets/real-world/indoor/Eval

