from imutils.video import VideoStream
import paho.mqtt.publish as publish
import numpy as np
import argparse
import cv2
import torch
from config import GlobalConfig
from utils import command_to_one_hot
import json
import torch.nn as nn
import os
import re
import sys
from models import CILModel

parser = argparse.ArgumentParser()
parser.add_argument("--rtsp", type=str, required=True, help="RTSP URL of the camera.")
parser.add_argument(
    "--ip", type=str, required=True, help="IP address of the MQTT broker."
)
parser.add_argument(
    "--port", type=int, default=1883, help="Port number of the MQTT broker."
)
parser.add_argument(
    "--topic", type=str, default="sensor_inputs", help="Topic of the MQTT broker."
)
parser.add_argument(
    "--sim2real",
    type=int,
    default=0,
    required=False,
    help="Enable Sim2Real or not",
)
parser.add_argument("--command", type=str, default="Straight")
parser.add_argument("--model_path", type=str, required=True)
parser.add_argument("--test_dropout", type=float, default=0.0)
parser.add_argument("--seed", type=int, default=2023)

args = parser.parse_args()

command_text = args.command

if torch.cuda.is_available():
    device = torch.device("cuda")
# elif torch.backends.mps.is_available():
#     device = torch.device("mps")
else:
    device = torch.device("cpu")

print(f"Using Device: {device}")

if args.sim2real:
    paths = ["../abstraction/depth_anything", "../abstraction/"]
    fastSAM_model_path = "../abstraction/weights/FastSAM-s.pt"
    sys.path.extend(paths)
    from depth_anything.depth_anything.dpt import DepthAnything
    from depth_anything.depth_anything.util.transform import (
        Resize,
        NormalizeImage,
        PrepareForNet,
    )
    
    from depth import DepthAnythingWrapper
    from fastsam import FastSAM, FastSAMPrompt

    depth_model = DepthAnythingWrapper("vits", device=device)
    fastSAM_model = FastSAM(fastSAM_model_path)


torch.manual_seed(args.seed)
np.random.seed(args.seed)
if device.type == "cuda":
    torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


config = GlobalConfig(root_dir="", setting="eval")

# Separate out model dir
if args.model_path.endswith(".pth"):
    model_dir = args.model_path.split("/")[:-1]
    model_dir = "/".join(model_dir)
else:
    model_dir = args.model_path


# Load the arguments file
args_file_path = os.path.join(model_dir, "args.txt")
with open(args_file_path, "r") as f:
    args_dict = json.load(f)


# Init the model
model = CILModel(
    args_dict["backbone"],
    cmd_len=config.num_commands,
    input_shape=config.img_resolution,
    use_act=args_dict["use_act"],
    dropout=0,
    bn=config.bn,
    less_cmd=args_dict["less_cmd"],
    prev_speed=args_dict["prev_speed"],
    test_dropout=args.test_dropout,
    seed=args.seed,
    reduce_channel=args.sim2real,
)


command_map = {
    "Left": 0,
    "Right": 1,
    "Straight": 2,
}

# Load the model
if os.path.isdir(args.model_path):
    model_files = [f for f in os.listdir(args.model_path) if f.startswith("model")]
    if len(model_files) > 0:
        epoch_numbers = [int(f.split("_")[-1].split(".")[0]) for f in model_files]
        epoch_number = max(epoch_numbers)
    else:
        raise ("Improper Path!")

    load_path = os.path.join(args.model_path, f"model_{epoch_number}.pth")
else:
    load_path = args.model_path

model.load_state_dict(torch.load(load_path, map_location="cpu"), strict=False)
model.to(device)
model.eval()
print(f"Model Loaded from: {load_path}")


def apply_dropout(m):
    if type(m) == nn.Dropout:
        m.train()


if args.test_dropout > 0:
    model.apply(apply_dropout)
    print("Added: Test Time Dropout!")
    for name, module in model.named_modules():
        if isinstance(module, nn.Dropout):
            print(f"{name}: training={module.training}")


stop = True
frame_count = 0
prev_speed = 0.0

vs = VideoStream(args.rtsp).start()

while True:
    frame = vs.read()

    if frame is None:
        break

    command_val = torch.tensor(command_map[command_text]).unsqueeze(0)
    command = command_to_one_hot(command_val, num_classes=config.num_commands).to(
        device, dtype=torch.float32
    )

    if args_dict["prev_speed"]:
        prev_speed = torch.tensor(prev_speed).unsqueeze(0).to(device)
        command = torch.cat([command, prev_speed.unsqueeze(1)], dim=1)

    frame_original = frame.copy()
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    if args.sim2real:
        # FastSAM
        if torch.cuda.is_available():
            fsam_device = torch.device("cuda")
        elif torch.backends.mps.is_available():
            fsam_device = torch.device("mps")
        else:
            fsam_device = torch.device("cpu")


        everything_results = fastSAM_model(
            frame,
            device=fsam_device,
            retina_masks=True,
            imgsz=512,
            conf=0.4,
            iou=0.9,
            verbose=False
        )
        prompt_process = FastSAMPrompt(frame, everything_results, device=fsam_device)
        prompt_process.img = np.zeros_like(prompt_process.img)
        ann = prompt_process.everything_prompt()
        semantics = prompt_process.plot_to_result(
            annotations=ann,
            withContours=False,
            better_quality=True,
        )

        # Depth
        depth = depth_model(frame_original)

        # Concatenate
        depth = np.expand_dims(depth, axis=2)
        mask_depth = np.concatenate([semantics, depth], axis=2)
        mask_depth = np.transpose(mask_depth, (2, 0, 1))
        mask_depth = np.expand_dims(mask_depth, axis=0)
        rgb = torch.tensor(mask_depth).to(device, dtype=torch.float32)
    else:
        frame = np.transpose(frame, (2, 0, 1))
        frame = np.expand_dims(frame, axis=0)
        rgb = torch.tensor(frame).to(device, dtype=torch.float32)

    cv2.imshow("Frame", frame[:,:,::-1])
    if args.sim2real:
        cv2.imshow("Semantics", semantics)
        cv2.imshow("Depth", depth)
    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break


    # Inference
    with torch.no_grad():
        pred_steer, pred_throttle = model(rgb, cmd_input=command)
    pred_steer = pred_steer.squeeze().item()
    pred_throttle = pred_throttle.squeeze().item()

    if stop:
        pred_throttle = 0.0

    data_to_send = {
        "throttle": pred_throttle,
        "steer": pred_steer,
        "command": command_text,
    }

    print(data_to_send)
    json_data = json.dumps(data_to_send)

    # Publish the data to the MQTT broker
    publish.single(args.topic, json_data, hostname=args.ip, port=args.port)

    key = cv2.waitKey(1)
    if key == ord("w"):
        command_text = "Straight"
    elif key == ord("a"):
        command_text = "Left"
    elif key == ord("d"):
        command_text = "Right"
    elif key == ord("s"):
        stop = True
    elif key == ord("r"):
        stop = False
    elif key == ord("q"):
        break

    label = {
        "Throttle": pred_throttle,
        "Steer": pred_steer,
        "Command": command_text,
        "Intervention": stop,
    }

    prev_speed = pred_throttle

    if frame_count == 0 and stop:
        pass
    else:
        frame_count += 1
