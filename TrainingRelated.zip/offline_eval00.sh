python evaluate_offline00.py --model_root_dir ./models --eval_data /projectnb/rlvn/students/vrs/DLProject/outdoor/FastSAM_Eval && python evaluate_offline00.py --model_root_dir /projectnb/rlvn/students/vrs/DLProject/Custom_Arch/agent/models --eval_data /projectnb/rlvn/students/vrs/DLProject/indoor/FastSAM_Eval

