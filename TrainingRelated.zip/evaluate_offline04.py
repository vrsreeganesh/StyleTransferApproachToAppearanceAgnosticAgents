import numpy as np; import argparse; import cv2; import torch; from config import GlobalConfig; from utils import command_to_one_hot;
import json; import torch.nn as nn; import os; import torch.nn.functional as F; import pandas as pd; from tqdm import tqdm; import re;
import warnings; from models import CILModel; import datetime; import time; import sys;

def fetchcurrenttime():
    now = datetime.datetime.now(); formatted_date_time = now.strftime("%m_%d_%H_%M_%S");
    return formatted_date_time

warnings.filterwarnings("ignore")

parser = argparse.ArgumentParser()
parser.add_argument(
    "--model_root_dir", type=str, help="Root directory of the model"
)
parser.add_argument(
    "--eval_data", type=str, help="Path to the expert data for evaluation"
)

print("Running Offline Eval")

# FUNCTIONS #####################################################################################################
def Q(sigma, x):
    sigma = sigma
    if x < -sigma:
        return -1
    elif -sigma <= x < sigma:
        return 0
    else:
        return 1
def heaviside_step(x):
    device = x.device
    t1 = torch.tensor(0.5, dtype=torch.float32, device=device)
    t2 = torch.tensor(1, dtype=torch.float32, device=device)
    t3 = torch.tensor(0, dtype=torch.float32, device=device)
    return torch.where(x == 0, t1, torch.where(x > 0, t2, t3))
def load_new_model(model_path):
    model.load_state_dict(torch.load(model_path, map_location="cpu"), strict=False)
    model.eval()

    model.to(device)
    return model

args = parser.parse_args()

# setting the device
if torch.cuda.is_available():
    device = torch.device("cuda")
elif torch.backends.mps.is_available():
    device = torch.device("mps")
else:
    device = torch.device("cpu")

command_map = {
    "Left": 0,
    "Right": 1,
    "Straight": 2,
}

config = GlobalConfig(setting='eval')

# Set the model setting
setting = "indoor" if "indoor" in args.eval_data.lower() else "outdoor"
if setting == "outdoor": assert "outdoor" in args.eval_data.lower()

# Get the models and extract properties from in that
model_dir_names = os.listdir(args.model_root_dir)


df = pd.DataFrame(columns=[
    "Model_Name",
    "Model_Arch",
    "Setting",
    "Sim2Real_Method",
    "Steer_MAE",
    "Steer_MSE",
    "SW_Steer_MAE",
    "SW_Steer_MSE",
    "Action_MAE",
    "Action_MSE",
    "SW_Action_MAE",
    "SW_Action_MSE",
    "QCE",
    "TRE",
    "GT_Steer",
    "GT_Throttle",
    "Pred_Steer",
    "Pred_Throttle",
    ])

# Load the expert data based on the indoor/outdoor setting
assert setting in ["indoor", "outdoor"]
label_dirs = []
rgb_dirs = []
if setting == "indoor":
    routes = os.listdir(args.eval_data)
    for route in routes:
        runs = os.listdir(os.path.join(args.eval_data, route))
        runs = [run for run in runs if "run_" in run]
        runs = sorted(runs, key=lambda x: int(x.split("_")[1]))
        run = runs[-1]
        data_dir = os.path.join(args.eval_data, route, run)
        rgb_dir = os.path.join(data_dir, "rgb")
        label_dir = os.path.join(data_dir, "fixed_label_data")
        rgb_dirs.append(rgb_dir)
        label_dirs.append(label_dir)

if setting == "outdoor":
    routes = os.listdir(args.eval_data)
    for route in routes:
        runs = os.listdir(os.path.join(args.eval_data, route))
        runs = [run for run in runs if "run_" in run]
        runs = sorted(runs, key=lambda x: int(x.split("_")[1]))
        run = runs[-1]
        data_dir = os.path.join(args.eval_data, route, run)
        rgb_dir = os.path.join(data_dir, "rgb")
        label_dir = os.path.join(data_dir, "label_data")
        rgb_dirs.append(rgb_dir)
        label_dirs.append(label_dir)

num_files = sum(len(os.listdir(rgb_dir)) for rgb_dir in rgb_dirs)

pbar = tqdm(total=len(model_dir_names) * num_files, ascii=True)

for model_dir_name in model_dir_names:
    model_dir_path = os.path.join(args.model_root_dir, model_dir_name)
    print("///////////////////model_dir_name = ", model_dir_name)
    data_type = model_dir_name.split("_")[1]
    model_files = os.listdir(model_dir_path)
    model_files = [model_file for model_file in model_files if (model_file.startswith("model") and model_file.endswith(".pth"))]
    model_args_file = os.path.join(model_dir_path, "args.txt")
    with open(model_args_file, "r") as f:
        model_args = json.loads(f.read())

    model_arch = model_args["backbone"]

    # Choose the model weight for the highest epoch
    highest_epoch = 0
    for model_file in model_files:
        model_epoch = int(model_file.split("_")[-1].split(".")[0])
        if model_epoch > highest_epoch:
            highest_epoch = model_epoch

    print("We're evaluating = ", f"model_{highest_epoch}.pth")
    

    model_weight_path = os.path.join(model_dir_path, f"model_{highest_epoch}.pth")

    print(f"Model: {model_arch} | Data Type: {data_type} | Model Dir: {model_dir_name} | Model Weight: {model_weight_path}")

    # Load the model
    model = CILModel(
        model_arch,
        cmd_len=config.num_commands,
        input_shape=config.img_resolution,
        use_act=model_args["use_act"],
        dropout=model_args["dropout"],
        bn=config.bn,
        less_cmd=model_args["less_cmd"],
        prev_speed=model_args["prev_speed"],
        num_channels=model_args["num_channels"],
    )
    
    #load weights
    model.load_state_dict(torch.load(model_weight_path, map_location="cpu"), strict=False)
    model.to(device)
    model.eval()

    for rgb_dir, label_dir in zip(rgb_dirs, label_dirs):
        image_filenames = os.listdir(rgb_dir)
        label_filenames = os.listdir(label_dir)

        image_paths = [os.path.join(rgb_dir, image_filename) for image_filename in image_filenames]
        label_paths = [os.path.join(label_dir, label_filename) for label_filename in label_filenames]

        for image_path, label_path in zip(image_paths, label_paths):
            label = json.load(open(label_path, "r"))
            
            # print("data_type = ", data_type)
            # time.sleep(5)
            # we do not touch this because the evaluation should be done on natural inputs since this is a sim2real project. 
            data_type = "rgb" # do not touch this !!!!!!!!!!!!!!!!!!!!!!!!!!

            if data_type == "rgb":
                image = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                if setting == 'outdoor':
                    image = image[:406, :, :]
                    image = cv2.resize(image, config.img_resolution[::-1])
                img_in = image.copy()
            elif data_type == "rgb_NST":
                image = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                if setting == 'outdoor':
                    image = image[:406, :, :]
                    image = cv2.resize(image, config.img_resolution[::-1])
                img_in = image.copy()
            elif data_type == "rgbd":
                image = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                depth = cv2.imread(image_path.replace("rgb", "rgb_depths"), cv2.IMREAD_UNCHANGED)
                if setting == 'outdoor':
                    image = image[:406, :, :]
                    image = cv2.resize(image, config.img_resolution[::-1])
                    depth = cv2.resize(depth, config.img_resolution[::-1])
                depth = np.expand_dims(depth, axis=2)
                img_in = np.concatenate([image, depth], axis=2)
            elif data_type == "mask":
                mask = cv2.imread(image_path.replace("rgb", "rgb_sam_masks"), cv2.IMREAD_UNCHANGED)
                mask = cv2.cvtColor(mask, cv2.COLOR_BGR2RGB)
                if setting == 'outdoor':
                    mask = mask[:406, :, :]
                    mask = cv2.resize(mask, config.img_resolution[::-1])
                img_in = mask.copy()
            elif data_type == "maskd":
                mask = cv2.imread(image_path.replace("rgb", "rgb_sam_masks"), cv2.IMREAD_UNCHANGED)
                mask = cv2.cvtColor(mask, cv2.COLOR_BGR2RGB)
                depth = cv2.imread(image_path.replace("rgb", "rgb_depths"), cv2.IMREAD_UNCHANGED)
                if setting == 'outdoor':
                    mask = mask[:406, :, :]
                    mask = cv2.resize(mask, config.img_resolution[::-1])
                    depth = cv2.resize(depth, config.img_resolution[::-1])
                depth = np.expand_dims(depth, axis=2)
                img_in = np.concatenate([mask, depth], axis=2)
            elif data_type == "contd":
                contours = cv2.imread(image_path.replace("rgb", "rgb_sam_contours"), cv2.IMREAD_UNCHANGED)
                contours = cv2.cvtColor(contours, cv2.COLOR_BGR2RGB)
                depth = cv2.imread(image_path.replace("rgb", "rgb_depths"), cv2.IMREAD_UNCHANGED)
                if setting == 'outdoor':
                    contours = contours[:406, :, :]
                    contours = cv2.resize(contours, config.img_resolution[::-1])
                    depth = cv2.resize(depth, config.img_resolution[::-1])
                depth = np.expand_dims(depth, axis=2)
                img_in = np.concatenate([contours, depth], axis=2)
            elif data_type == "maskcontd":
                mask = cv2.imread(image_path.replace("rgb", "rgb_sam_masks_with_contours"), cv2.IMREAD_UNCHANGED)
                mask = cv2.cvtColor(mask, cv2.COLOR_BGR2RGB)
                depth = cv2.imread(image_path.replace("rgb", "rgb_depths"), cv2.IMREAD_UNCHANGED)
                if setting == 'outdoor':
                    mask = mask[:406, :, :]
                    mask = cv2.resize(mask, config.img_resolution[::-1])
                    depth = cv2.resize(depth, config.img_resolution[::-1])
                depth = np.expand_dims(depth, axis=2)
                img_in = np.concatenate([mask, depth], axis=2)
            else:
                raise ValueError(f"Invalid data type: {data_type}")

            img_in = np.transpose(img_in, (2, 0, 1))
            img_in = torch.tensor(img_in).unsqueeze(0)

            throttle = label["Throttle"] if setting == "outdoor" else label["Throttle"] * 2
            steer = label["Steer"] if setting == "outdoor" else label["Steer"] * 2
            command_text = label["Command"]

            # Convert to tensor
            steer = torch.tensor(steer)
            throttle = torch.tensor(throttle)

            command_val = torch.tensor(command_map[command_text]).unsqueeze(0)
            command = command_to_one_hot(command_val, num_classes=config.num_commands)

            img_in = img_in.to(device, dtype=torch.float32)
            command = command.to(device, dtype=torch.float32)      

            if model_args["prev_speed"]:
                prev_speed = torch.tensor(prev_speed).unsqueeze(0).to(device)
                command = torch.cat([command, prev_speed.unsqueeze(1)], dim=1)

            # Inference
            pred_steer, pred_throttle = model(img_in, cmd_input=command)

            pred_steer = pred_steer.squeeze().cpu() / 0.75
            pred_throttle = pred_throttle.squeeze().cpu()

            prev_speed = pred_throttle

            # Steer Raw Loss
            steer_loss_mae = torch.nn.functional.l1_loss(pred_steer, steer, reduction="none")
            steer_loss_mse = torch.nn.functional.mse_loss(pred_steer, steer, reduction="none")

            # Throttle Raw Loss
            throttle_loss_mae = torch.nn.functional.l1_loss(pred_throttle, throttle, reduction="none")
            throttle_loss_mse = torch.nn.functional.mse_loss(pred_throttle, throttle, reduction="none")
    
            ego_vel = torch.where(throttle > 0.3, torch.tensor(2.3), torch.tensor(0.0))

            # Speed weighted Steer loss
            steer_loss_SW_mae = torch.nn.functional.l1_loss(pred_steer, steer, reduction="none") * torch.abs(ego_vel.squeeze())
            steer_loss_SW_mse = torch.nn.functional.mse_loss(pred_steer, steer, reduction="none") * torch.abs(ego_vel.squeeze())

            # Action Error
            action = torch.tensor([steer, throttle])
            pred_action = torch.tensor([pred_steer, pred_throttle])

            action_mae = torch.nn.functional.l1_loss(action, pred_action).sum()
            action_mse = torch.nn.functional.mse_loss(action, pred_action).sum()

            # Speed Weighted Action Error
            action_SW_mae = torch.nn.functional.l1_loss(action, pred_action, reduction="none") * torch.abs(ego_vel.squeeze())
            action_SW_mse = torch.nn.functional.mse_loss(action, pred_action, reduction="none") * torch.abs(ego_vel.squeeze())

            # ECCV 2018 paper metric parameters
            alpha = 0.1
            sigma = 0.05

            # Losses from the ECCV 2018 Paper (https://arxiv.org/abs/1809.04843)
            # Quantized Classification Error
            qce = []
            #for steer_pred, steer_gt in zip(pred_steer, steer):
            qce.append(1 - Q(sigma,pred_steer) == Q(sigma,steer))
            qce = torch.FloatTensor(np.array(qce)).to(device)

            # Thresholded Relative Error
            tre = heaviside_step(torch.abs(pred_steer - steer) - alpha * torch.abs(steer))

            # Append to the dataframe
            df = df.append({
                "Model_Name": model_dir_name,
                "Model_Arch": model_arch,
                "Setting": setting,
                "Sim2Real_Method": data_type,
                "Steer_MAE": steer_loss_mae.item(),
                "Steer_MSE": steer_loss_mse.item(),
                "SW_Steer_MAE": steer_loss_SW_mae.sum().item(),
                "SW_Steer_MSE": steer_loss_SW_mse.sum().item(),
                "Action_MAE": action_mae.item(),
                "Action_MSE": action_mse.item(),
                "SW_Action_MAE": action_SW_mae.sum().item(),
                "SW_Action_MSE": action_SW_mse.sum().item(),
                "QCE": qce.item(),
                "TRE": tre.item(),
                "GT_Steer": steer.item(),
                "GT_Throttle": throttle.item(),
                "Pred_Steer": pred_steer.item(),
                "Pred_Throttle": pred_throttle.item(),
            }, ignore_index=True)
            pbar.update(1)


csvfilenametowrite = f"{setting}_results_" + os.path.basename(sys.argv[0])[:-3]+"_" +fetchcurrenttime()+".csv"
print("csvfilename = ", csvfilenametowrite)
df.to_csv(f"{setting}_results" + os.path.basename(sys.argv[0])[:-3]+"_" +fetchcurrenttime()+".csv", index=False)



















