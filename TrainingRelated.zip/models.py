import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torch.optim as optim
import timm


class MLPBlock(nn.Module):
    def __init__(self, in_features, out_features, activation, dropout, bn):
        super(MLPBlock, self).__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.activation = getattr(F, activation)
        self.bn = nn.BatchNorm1d(out_features) if bn else None
        self.dropout = nn.Dropout(dropout) if dropout > 0 else None

    def forward(self, x):
        x = self.linear(x)
        x = self.activation(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.dropout is not None:
            x = self.dropout(x)
        return x
    
class CNNBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, activation, conv_dropout, bn):
        super(CNNBlock, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding)
        self.activation = getattr(F, activation)
        self.bn = nn.BatchNorm2d(out_channels) if bn else None
        self.dropout = nn.Dropout(conv_dropout) if conv_dropout > 0 else None

    def forward(self, x):
        x = self.conv(x)
        x = self.activation(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.dropout is not None:
            x = self.dropout(x)
        return x

class MLP(nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim, activation, dropout, bn):
        super(MLP, self).__init__()
        self.mlp_layers = nn.Sequential(
            MLPBlock(in_dim, hidden_dim, activation, dropout, bn),
            MLPBlock(hidden_dim, out_dim, activation, dropout, bn)
        )

    def forward(self, x):
        x = self.mlp_layers(x)
        return x

class CNN(nn.Module):
    def __init__(self, depth, cnn_filters, kernel_sz, stride, padding, activation, conv_dropout, bn):
        super(CNN, self).__init__()
        self.cnn_layers = nn.ModuleList([
            CNNBlock(cnn_filters[i-1] if i > 0 else depth, cnn_filters[i], kernel_sz[i], stride[i], padding, activation, conv_dropout, bn)
            for i in range(len(cnn_filters))
        ])
        
        self.avg_pool = nn.AdaptiveAvgPool2d((5))

    def forward(self, x):
        for layer in self.cnn_layers:
            x = layer(x)
        x = self.avg_pool(x).flatten(1, -1)
        return x

class CILModel(nn.Module):
    def __init__(self, backbone_name, cmd_len=6, input_shape=(480, 720), use_act=True, dropout=0.0, prev_speed=False, bn=False, less_cmd=False, test_dropout=0.0, seed=2023, num_channels=3):
        print(f"Using Backbone: {backbone_name}")

        super(CILModel, self).__init__()
        torch.manual_seed(seed)
        self.backbone_name = backbone_name
        self.less_cmd = less_cmd
        self.num_channels = num_channels
        mlp_output_size = 16

        # Concatenate Speed
        if prev_speed:
            cmd_len += 1
        
        if self.num_channels != 3:
            self.preconv = nn.Conv2d(self.num_channels, 3, kernel_size=3, stride=1, padding=1)


        if "pilotnet" in backbone_name.lower():
            self.backbone = CNN(
            3,
            cnn_filters=[24, 36, 48, 64, 64],
            kernel_sz=[5, 5, 5, 3, 3],
            stride=[2, 2, 2, 1, 1],
            padding="valid",
            activation="relu",
            conv_dropout=dropout,
            bn=bn
            )
            dummy_img = torch.randn(1, 3, input_shape[0], input_shape[1])
            num_features = self.calculate_cnn_output_size(dummy_img)
            self.fc = nn.Linear(mlp_output_size + num_features, 512)
        else:
            self.backbone = timm.create_model(backbone_name, pretrained=True)        
            self.backbone.reset_classifier(0)
            self.fc = nn.Linear(mlp_output_size + self.backbone.num_features, 512)
        
        self.mlp = MLP(cmd_len, 16, mlp_output_size, "relu", dropout, bn)

        if self.less_cmd:
            cmd_len = 0

        self.fc1 = nn.Linear(512+cmd_len, 128) 
        self.fc2 = nn.Linear(128+cmd_len, 64)

        if test_dropout > 0:

            self.fc1 = nn.Sequential(
                            nn.Linear(512+cmd_len, 128),
                            nn.Dropout(test_dropout),
            )
        

        # NNs for Controls (Steer, Throttle, Brake)
        if dropout > 0:
            self.control_linear_real = nn.Sequential(
                            nn.Linear(64+cmd_len, 32),
                            nn.Dropout(dropout),
                            nn.ReLU(inplace=True),
        )
        else:
            self.control_linear_real = nn.Sequential(
                            nn.Linear(64+cmd_len, 32),
                            nn.ReLU(inplace=True),
            )
        if use_act:
            self.throttle_linear_real = nn.Sequential(
                                nn.Linear(32, 1),
                                nn.Sigmoid(),
            )
            self.steer_linear_real = nn.Sequential(
                                nn.Linear(32, 1),
                                nn.Tanh(),
            )
        else:
            self.throttle_linear_real = nn.Sequential(
                            nn.Linear(32, 1),
            )
            self.steer_linear_real = nn.Sequential(
                                nn.Linear(32, 1),
            )

    def calculate_cnn_output_size(self, x):
        x = self.backbone(x)
        x = x.view(x.shape[0], -1)
        return x.shape[1]
    
    def controls_head(self, z, commands):
        if self.less_cmd:
            z = self.control_linear_real(z)
        else:
            z = torch.cat((z, commands), dim=1)
            z = self.control_linear_real(z)

        throttle = self.throttle_linear_real(z)
        steer = self.steer_linear_real(z)

        return steer, throttle

    def forward(self, img_input, cmd_input):
        
        img_input = img_input / 255.0
        mlp_output = self.mlp(cmd_input)


        if self.num_channels != 3:
            img_input = F.relu(self.preconv(img_input))


        cnn_output = self.backbone(img_input)
        combined_input = torch.cat((mlp_output, cnn_output), dim=1)

        x = F.relu(self.fc(combined_input))

        if self.less_cmd:
            x = F.relu(self.fc1(x))
            x = F.relu(self.fc2(x))
        else:
            x = torch.cat((cmd_input, x), dim=1)
            x = F.relu(self.fc1(x))
            x = torch.cat((cmd_input, x), dim=1)
            x = F.relu(self.fc2(x))

        steer, throttle = self.controls_head(x, cmd_input)
        return steer, throttle


def normalize_imagenet(x):
    """ Normalize input images according to ImageNet standards.
    Args:
        x (tensor): input images
    """
    x = x.clone()
    x[:, 0] = ((x[:, 0] / 255.0) - 0.485) / 0.229
    x[:, 1] = ((x[:, 1] / 255.0) - 0.456) / 0.224
    x[:, 2] = ((x[:, 2] / 255.0) - 0.406) / 0.225
    
    return x




# Example usage
if __name__ == "__main__":
    # Example parameters
    backbone_name = 'regnety_002'
    
    # Create the model
    model = CILModel(backbone_name, cmd_len=6, use_act=False, dropout=0.0, prev_speed=True, less_cmd=False)
    
    # Print the modified model
    # print(model)
    print(model(torch.randn(1, 3, 480, 720), torch.randn(1, 6)))
