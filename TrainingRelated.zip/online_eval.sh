# python online_eval.py \
#     --rtsp http://192.168.93.110:8080/video \
#     --ip 192.168.93.253 \
#     --model_path ./models/s2rp1_regnety_016_dp0.0_regnety_016 \
#     --sim2real 1

python online_eval.py \
    --rtsp http://10.192.30.182:8080/video \
    --ip 192.168.93.253 \
    --model_path ./models/s2rp1_regnety_016_dp0.0_regnety_016 \
    --sim2real 1