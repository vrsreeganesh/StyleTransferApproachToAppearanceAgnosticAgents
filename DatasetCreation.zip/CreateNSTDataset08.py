'''
===============================================================
Aim:
    Creating Neural Style Transferred Dataset
    content_weight_arg = 1e-10; styleweightarg = 1e4;    
    Plus flipping
===============================================================
'''

# importing the libraries
import sys

# functiond definitions
#############################################################################################################################
import torch; import numpy as np; import matplotlib.pyplot as plt; import torchvision; import os; # to get path and stuff
import random; import datetime; import PIL; # used in the image loader function

# Choosing device
if torch.cuda.is_available(): device = "cuda"
# elif torch.backends.mps.is_available(): device = "mps"
else: device = "cpu"

imsize0 = 480; imsize1 = 640;
loader = torchvision.transforms.Compose([ torchvision.transforms.Resize((imsize0, imsize1)), torchvision.transforms.ToTensor()])
def image_loader(image_name):
    image = PIL.Image.open(image_name)
    # fake batch dimension required to fit network's input dimensions
    image = loader(image).unsqueeze(0)
    return image.to(device, torch.float)
class ContentLoss(torch.nn.Module):
    def __init__(self, target,):
        super(ContentLoss, self).__init__()
        # we 'detach' the target content from the tree used
        # to dynamically compute the gradient: this is a stated value,
        # not a variable. Otherwise the forward method of the criterion
        # will throw an error.
        self.target = target.detach()
    def forward(self, input):
        self.loss = torch.nn.functional.mse_loss(input, self.target)
        return input
def gram_matrix(input):
    a, b, c, d = input.size()  # a=batch size(=1)
    # b=number of feature maps
    # (c,d)=dimensions of a f. map (N=c*d)
    features = input.view(a * b, c * d)  # resize F_XL into \hat F_XL
    G = torch.mm(features, features.t())  # compute the gram product
    # we 'normalize' the values of the gram matrix
    # by dividing by the number of element in each feature maps.
    return G.div(a * b * c * d)
class StyleLoss(torch.nn.Module):
    def __init__(self, target_feature):
        super(StyleLoss, self).__init__(); self.target = gram_matrix(target_feature).detach()
    def forward(self, input):
        G = gram_matrix(input); self.loss = torch.nn.functional.mse_loss(G, self.target)
        return input
class Normalization(torch.nn.Module):
    def __init__(self, mean, std):
        super(Normalization, self).__init__()
        # .view the mean and std to make them [C x 1 x 1] so that they can
        # directly work with image Tensor of shape [B x C x H x W].
        # B is batch size. C is number of channels. H is height and W is width.
        # self.mean = torch.tensor(mean).view(-1, 1, 1)
        # self.std = torch.tensor(std).view(-1, 1, 1)

        # !!! This is my addition due to some compiler errors
        self.mean = mean.clone().detach().view(-1,1,1); self.std = std.clone().detach().view(-1,1,1)
    def forward(self, img):
        # normalize ``img``
        return (img - self.mean) / self.std
content_layers_default = ['conv_4']
style_layers_default = ['conv_1', 'conv_2', 'conv_3', 'conv_4', 'conv_5']
# content_layers_default = ['conv_6']
# style_layers_default = ['conv_1', 'conv_2', 'conv_3']
def get_style_model_and_losses(cnn, normalization_mean, normalization_std,
                               styleimage, contentimage,
                               content_layers=content_layers_default,
                               style_layers=style_layers_default):
    # normalization module
    normalization = Normalization(normalization_mean, normalization_std)

    # just in order to have an iterable access to or list of content/style
    # losses
    content_losses = []; style_losses = []

    # assuming that ``cnn`` is a ``nn.Sequential``, so we make a new ``nn.Sequential``
    # to put in modules that are supposed to be activated sequentially
    model = torch.nn.Sequential(normalization)

    i = 0  # increment every time we see a conv
    for layer in cnn.children():
        if isinstance(layer, torch.nn.Conv2d):
            i += 1; name = 'conv_{}'.format(i)
        elif isinstance(layer, torch.nn.ReLU):
            name = 'relu_{}'.format(i)
            # The in-place version doesn't play very nicely with the ``ContentLoss``
            # and ``StyleLoss`` we insert below. So we replace with out-of-place
            # ones here.
            layer = torch.nn.ReLU(inplace=False)
        elif isinstance(layer, torch.nn.MaxPool2d): name = 'pool_{}'.format(i)
        elif isinstance(layer, torch.nn.BatchNorm2d): name = 'bn_{}'.format(i)
        else: raise RuntimeError('Unrecognized layer: {}'.format(layer.__class__.__name__))

        model.add_module(name, layer)

        if name in content_layers:
            # add content loss:
            target = model(contentimage).detach(); content_loss = ContentLoss(target)
            model.add_module("content_loss_{}".format(i), content_loss); content_losses.append(content_loss)

        if name in style_layers:
            # add style loss:
            target_feature = model(styleimage).detach(); style_loss = StyleLoss(target_feature)
            model.add_module("style_loss_{}".format(i), style_loss); style_losses.append(style_loss)

    # now we trim off the layers after the last content and style losses
    for i in range(len(model) - 1, -1, -1):
        if isinstance(model[i], ContentLoss) or isinstance(model[i], StyleLoss):
            break
    model = model[:(i + 1)]
    return model, style_losses, content_losses
def run_style_transfer(cnn, normalization_mean, normalization_std,
                       contentimage, styleimage, input_img, num_steps=300,
                       style_weight=1000000, content_weight=1):
    # Choosing device
    if torch.cuda.is_available(): device = "cuda"
    elif torch.backends.mps.is_available(): device = "mps"
    else: device = "cpu"

    debugflag = 0;
    if debugflag: print("\t> run_style_transfer| ");
    if debugflag: print("\t> run_style_transfer| Entered ");

    # moving to gpu (just in case they already aren't)
    if debugflag: print("\t> run_style_transfer| moving stuff to GPU");
    cnn = cnn.to(device); normalization_mean = normalization_mean.to(device); normalization_std = normalization_std.to(device);
    contentimage = contentimage.to(device); styleimage = styleimage.to(device); input_img = input_img.to(device);

    """Run the style transfer."""
    # print('Building the style transfer model..')
    if debugflag: print("\t> run_style_transfer| running the stylue transfer function")
    model, style_losses, content_losses = get_style_model_and_losses(cnn,
                                                                     normalization_mean, 
                                                                     normalization_std, 
                                                                     styleimage, 
                                                                     contentimage)

    # We want to optimize the input and not the model parameters so we
    # update all the requires_grad fields accordingly
    input_img.requires_grad_(True)
    # We also put the model in evaluation mode, so that specific layers 
    # such as dropout or batch normalization layers behave correctly. 
    model.eval(); model.requires_grad_(False)
    optimizer = get_input_optimizer(input_img)

    # print('Optimizing..')
    if debugflag: print("\t> run_style_transfer| starting the style transfer stuff. ");
    print("StyleLoss", end=  ": "); run = [0]
    num_steps = 250
    while run[0] <= num_steps:

        def closure():
            # correct the values of updated input image
            with torch.no_grad():
                input_img.clamp_(0, 1)

            optimizer.zero_grad(); model(input_img); style_score = 0; content_score = 0;
            for sl in style_losses: style_score += sl.loss; 
            for cl in content_losses: content_score += cl.loss
            style_score *= style_weight; content_score *= content_weight
            loss = style_score + content_score; loss.backward()

            run[0] += 1
            if run[0] % 50 == 0:
                # print("run {}:".format(run))
                # print('Style Loss : {:4f} Content Loss: {:4f}'.format(
                #     style_score.item(), content_score.item()))
                print('{:4f}'.format(style_score.item()), end = " | ")

            return style_score + content_score
        optimizer.step(closure)
    print()

    # a last correction...
    with torch.no_grad():
        input_img.clamp_(0, 1)

    return input_img
def get_input_optimizer(input_img):
    # this line to show that input is a parameter that requires a gradient
    # optimizer = optim.LBFGS([input_img])
    optimizer = torch.optim.LBFGS([input_img], lr = 1e-1)
    return optimizer
def NSTSetup(styleimage, contentimage, content_weight_arg = 1e-2, style_weightarg=1e6):
    # Choosing device
    if torch.cuda.is_available(): device = "cuda"
    elif torch.backends.mps.is_available(): device = "mps"
    else: device = "cpu"
    debugflag = 0

    if debugflag: print("\t> NSTSetup| ")
    if debugflag: print("\t> NSTSetup| Entered the function")

    # moving things to GPU
    styleimage = styleimage.to(device); contentimage = contentimage.to(device);
    if debugflag: print("\t> NSTSetup| moved to device")

    # cnn = torchvision.models.vgg19(weights=torchvision.models.VGG19_Weights.DEFAULT).features.eval()
    cnn = torchvision.models.vgg19(pretrained=True).features.eval()
    cnn = cnn.to(device)
    cnn_normalization_mean = torch.tensor([0.485, 0.456, 0.406]); cnn_normalization_std = torch.tensor([0.229, 0.224, 0.225])
    if debugflag: print("\t> NSTSetup| model related")

    input_img = contentimage.clone()

    contentimage = contentimage.reshape([contentimage.shape[0],3,imsize0,imsize1])
    styleimage = styleimage.reshape([contentimage.shape[0],3,imsize0,imsize1])
    input_img = input_img.reshape([contentimage.shape[0],3,imsize0,imsize1])
    if debugflag: print("\t> NSTSetup| reshaping stuff")

    # output = run_style_transfer(cnn, 
    #                             cnn_normalization_mean,
    #                             cnn_normalization_std,
    #                             contentimage, 
    #                             styleimage, 
    #                             input_img,
    #                             style_weight=1e6,
    #                             content_weight=1e-2) #1e3, 1e2, 5e2, 1e3, 3e2, 2.5e2 is good, originally 1
    if debugflag: print("\t> NSTSetup| before calling run_style_transfer")
    output = run_style_transfer(cnn, 
                                cnn_normalization_mean,
                                cnn_normalization_std,
                                contentimage, 
                                styleimage, 
                                input_img,
                                style_weight=style_weightarg,
                                content_weight=content_weight_arg) #1e3, 1e2, 5e2, 1e3, 3e2, 2.5e2 is good, originally 1
    
    return output
def fetchcurrenttime():
    now = datetime.datetime.now(); formatted_date_time = now.strftime("%m_%d_%H_%M_%S");
    return formatted_date_time
#############################################################################################################################
def find_directories_with_name(root_directory, target_name):
    # Initialize an empty list to store the paths of directories
    found_directories = []

    # Walk through the directory tree starting from the root_directory
    for root, dirs, _ in os.walk(root_directory):
        # Check if any of the directories in the current level match the target name
        for dir_name in dirs:
            if dir_name == target_name:
                # If a match is found, append the full path to the list
                found_directories.append(os.path.join(root, dir_name))

    return found_directories
def create_directory_if_not_exists(directory):
    # Check if the directory already exists
    if not os.path.exists(directory):
        # If it doesn't exist, create it
        os.makedirs(directory)
        print("Directory created:", directory)
    else:
        print("Directory already exists:", directory)
def list_png_files(directory):
    # Initialize an empty list to store PNG files
    png_files = []

    # Iterate through all files in the directory
    for root, dirs, files in os.walk(directory):
        for file in files:
            # Check if the file has a .png extension
            if file.endswith(".png"):
                # If it does, add the file path to the list
                png_files.append(os.path.join(root, file))

    # Return the list of PNG files
    return png_files
def fetchpathtocurrentcallingscript():
    return os.path.realpath(__file__)
def styletransferandcreatedataset(pathtofoldercontainingsourceimages, pathtofoldercontainingsavedimages):

    # list of paths to the iamges
    listcontainingpngfiles = list_png_files(pathtofoldercontainingsourceimages)
    var00 = [os.path.basename(x) for x in listcontainingpngfiles]

    # TO DO: list the files in the corresponding NST folder and remove those from this list.
    nst_list = list_png_files(pathtofoldercontainingsavedimages);
    var01 = [os.path.basename(x) for x in nst_list]

    # subtracting
    todolist = list(set(var00) - set(var01));

    # reconstructing the paths
    listcontainingpngfiles = [os.path.join(pathtofoldercontainingsourceimages,x) for x in todolist]

    print("len(todolist) = ", len(todolist))
    if len(todolist)==0:
        return 

    # choosing batch size
    batchsize = 8;
    numfiles = len(listcontainingpngfiles);

    for i in range(0, numfiles, batchsize):
        print("======================================")
        # getting source images /////////////////////////////////////////////////////////////////////////////////////////////////
        listoffilestoprocessinthisiteration = listcontainingpngfiles[i:i+batchsize];
        for i in range(len(listoffilestoprocessinthisiteration)):
            var00 = image_loader(listoffilestoprocessinthisiteration[i]); # loading an image
            if i==0: rgb = var00 # styletensor is the tensor we'll use to stack style tensors. 
            else: rgb = torch.cat((rgb, var00), axis = 0); # stacking style images to the styletensor
        
        
        ################################################################################################################
        ################################################################################################################
        ######################################      NST      ###########################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        debugflag = 1;
        writetofileorno = 0
        
        # making all the print statements be written to a file /////////////////////////////////////
        if writetofileorno==1:
            statusfilepath = fetchpathtocurrentcallingscript()[:-3]+".txt";
            print("statusfilepath = ", statusfilepath)
            statusfile = open(statusfilepath, 'a+') # opening the file
            sys.stdout = statusfile 
        print("///////////////////////////////////////////////////////////////////////////////////////////////////////////")
        
        # writing down status
        print("> pathtofoldercontainingsourceimages = ", pathtofoldercontainingsourceimages)
        print("> pathtofoldercontainingsavedimages = ", pathtofoldercontainingsavedimages)

        # This section of code runs a certrain percentage of times. 
        percentageoftimestostyletransfer = 1
        if random.random() < percentageoftimestostyletransfer:
            # getting the style images //////////////////////////////////////////////////////////////////////////////////////////////
            texturedirectory = '/projectnb/rlvn/students/vrs/transfuser/RLVNFinalSubmission/Texture/'
            stylefilenames = [texturedirectory+file for file in os.listdir(texturedirectory)]               # finding style file names
            stylerandomindices = [random.randint(0, len(stylefilenames)-1) for _ in range(rgb.shape[0])]    # choosing a random number of indices
            stylerandomnames = [stylefilenames[x] for x in stylerandomindices] # finding a random set of images
            
            # creating a tensor of style images //////////////////////////////////////////////////////////////////////////
            for i in range(rgb.shape[0]):
                var00 = image_loader(stylerandomnames[i]); # loading an image
                if debugflag: print("var00.shape = ", var00.shape)
                if i==0: styletensor = var00 # styletensor is the tensor we'll use to stack style tensors. 
                else: styletensor = torch.cat((styletensor, var00), axis = 0); # stacking style images to the styletensor
            styletensor = styletensor.to(device);
            rgb = rgb.to(device)

            # printing the shape of both ////////////////////////////////
            if debugflag: print("> rgb.shape = ", rgb.shape)
            if debugflag: print("> styletensor.shape", styletensor.shape)

            # styletransferring ///////////////////////////////////////////////////////////////////////////////////////
            '''This is where style transfer occurs.'''
            content_weight_arg = 1e-10; styleweightarg = 1e4;
            output = NSTSetup(styletensor, rgb, content_weight_arg=content_weight_arg, style_weightarg=styleweightarg);
            if debugflag: print("output.shape = ", output.shape)
            
            # colour mixing ///////////////////////////////////////////////////////////////////////////////////////////////////////
            '''
            Here, we're randomly permuting the channels so that the colours are randomly changed. Sure, this does cause issues in the traffic lights and other stuff, but I'm guessing it'll correlate the position of colours with the actions associated with green light and red light and whatever. 
            '''
            colourmixing = [var00.item() for var00 in torch.randperm(3)];
            if debugflag: print("colourmixing = ", colourmixing)
            output = output[:, colourmixing, :,:]

            # saving the images //////////////////////////////////////////////////////////////////////////////////////////
            for i00 in range(len(listoffilestoprocessinthisiteration)):
                basename = os.path.basename(listoffilestoprocessinthisiteration[i00]);
                torchvision.utils.save_image(output[i00,:,:,:], os.path.join(pathtofoldercontainingsavedimages, basename))
            rgb = output*255.0

        # closing file ///////////////////////////////////////////////////////////////////////////
        if writetofileorno==1:
            sys.stdout = sys.__stdout__ # this basically returns the whole thing to original state
            statusfile.close()
        
        ################################################################################################################
        ################################################################################################################
        ######################################      NST      ###########################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################
        ################################################################################################################


if __name__ == "__main__":

    meta_sourcelist = find_directories_with_name("/projectnb/rlvn/students/vrs/DLProject/sim2real-old-data", "rgb");

    for pathtofoldercontainingsourceimages in meta_sourcelist:
        print("pathtofoldercontainingsourceimages = ", pathtofoldercontainingsourceimages)
        pathtosave = pathtofoldercontainingsourceimages + "_NST_styleweightarg=1e4_ColourFlipping";
        print("pathtosave = ", pathtosave)
        create_directory_if_not_exists(pathtosave)
        styletransferandcreatedataset(pathtofoldercontainingsourceimages, pathtosave)

