#!/bin/bash -l

# specifying arguments to the batch job. Its easier to enter it here
#$ -P rlvn
#$ -l h_rt=24:00:00
#$ -N NST_10
#$ -m e
#$ -l gpus=1
#$ -l gpu_type=V100

# module loading
ml miniconda
conda activate /projectnb/rlvn/students/vrs/anaconda3/envs/tfuse

# running the training
python /projectnb/rlvn/students/vrs/DLProject/Miscellaneous/CreateNSTDataset10.py